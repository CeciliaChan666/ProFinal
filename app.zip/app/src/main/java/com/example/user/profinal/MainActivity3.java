package com.example.user.profinal;

    import android.app.AlertDialog;
    import android.content.DialogInterface;
    import android.content.Intent;
    import android.os.Bundle;
    import android.support.v7.app.AppCompatActivity;
    import android.view.Menu;
    import android.view.MenuItem;
    import android.view.View;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.ImageView;


    public class MainActivity3 extends AppCompatActivity {

        Button button0 , button1 , button2 , button3 , button4 , button5 , button6 ,
                button7 , button8 , button9 , buttonAdd , buttonSubtract , buttonDivide ,
                buttonMultiplication  , buttonC , buttonEqual, buttonDecimal ;

        EditText edit1 ;

        float value1 , value2 ;

        boolean add ,subtract ,multiplication ,divide ;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main3);

            button0 = (Button) findViewById(R.id.button0);
            button1 = (Button) findViewById(R.id.button1);
            button2 = (Button) findViewById(R.id.button2);
            button3 = (Button) findViewById(R.id.button3);
            button4 = (Button) findViewById(R.id.button4);
            button5 = (Button) findViewById(R.id.button5);
            button6 = (Button) findViewById(R.id.button6);
            button7 = (Button) findViewById(R.id.button7);
            button8 = (Button) findViewById(R.id.button8);
            button9 = (Button) findViewById(R.id.button9);
            buttonAdd = (Button) findViewById(R.id.buttonadd);
            buttonSubtract = (Button) findViewById(R.id.buttonsubtract);
            buttonMultiplication = (Button) findViewById(R.id.buttonmultiplication);
            buttonDivide = (Button) findViewById(R.id.buttondivide);
            buttonC = (Button) findViewById(R.id.buttonC);
            buttonEqual = (Button) findViewById(R.id.buttonequal);
            edit1 = (EditText) findViewById(R.id.edit1);
            buttonDecimal = (Button) findViewById(R.id.buttondecimal);


            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"1");
                }
            });

            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"2");
                }
            });

            button3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"3");
                }
            });

            button4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"4");
                }
            });

            button5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"5");
                }
            });

            button6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"6");
                }
            });

            button7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"7");
                }
            });

            button8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"8");
                }
            });

            button9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"9");
                }
            });

            button0.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+"0");
                }
            });

            buttonAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (edit1 == null){
                        edit1.setText("");
                    }else {
                        value1 = Float.parseFloat(edit1.getText() + "");
                        add = true;
                        edit1.setText(null);
                    }
                }
            });

            buttonSubtract.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    value1 = Float.parseFloat(edit1.getText() + "");
                    subtract = true ;
                    edit1.setText(null);
                }
            });

            buttonMultiplication.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    value1 = Float.parseFloat(edit1.getText() + "");
                    multiplication = true ;
                    edit1.setText(null);
                }
            });

            buttonDivide.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    value1 = Float.parseFloat(edit1.getText()+"");
                    divide = true ;
                    edit1.setText(null);
                }
            });

            buttonEqual.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    value2 = Float.parseFloat(edit1.getText() + "");

                    if (add == true){

                        edit1.setText(value1 + value2 +"");
                        add=false;
                    }


                    if (subtract == true){
                        edit1.setText(value1 - value2 +"");
                        subtract=false;
                    }

                    if (multiplication == true){
                        edit1.setText(value1 * value2 +"");
                        multiplication=false;
                    }

                    if (divide == true){
                        edit1.setText(value1 / value2 +"");
                        divide=false;
                    }
                }
            });

            buttonC.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText("");
                }
            });

            buttonDecimal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit1.setText(edit1.getText()+".");
                }
            });
        }
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu1, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {

            String Name = "Cecilia Chan Wan Ting";
            String StudentId = "P18009703";
            String PersonalMessage = "The App is Created By Cecilia Chan";
            Intent intent = new Intent();
            switch (item.getItemId())
            {

                case R.id.menu_about:
                    ImageView image = new ImageView(this);
                    image.setImageResource(R.drawable.profilepicture);
                    AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                    alertDialog.setTitle("About this App");
                    alertDialog.setMessage(Name + "\n" + StudentId + "\n" + PersonalMessage + "\n"+"\n");
                    alertDialog.setView(image);
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            //TODO auto-generated stub
                        }
                    });
                    alertDialog.show();
                    return true;
                case R.id.currency:
                    intent.setClass(MainActivity3.this, CurrencyConverter.class);
                    MainActivity3.this.startActivity(intent);
                    return true;
                case R.id.menu_exit:
                    finish();
                    return true;
                default:
                    return super.onOptionsItemSelected(item);
            }
        }

    }