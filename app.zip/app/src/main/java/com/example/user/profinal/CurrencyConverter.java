package com.example.user.profinal;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

public class CurrencyConverter extends AppCompatActivity {

    EditText ringgit, dollar;
    RadioButton rbRinggit, rbDollar;
    Button buttonConvert, buttonCancel;
    String checkRinggit, checkDollar;
    double result;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.currency_converter);
        ringgit = (EditText)findViewById(R.id.ringgit);
        dollar = (EditText)findViewById(R.id.dollar);
        rbRinggit = (RadioButton)findViewById(R.id.rbRinggit);
        rbDollar = (RadioButton)findViewById(R.id.rbDollar);
        buttonConvert = (Button)findViewById(R.id.buttonConvert);
        buttonCancel = (Button)findViewById(R.id.buttonCancel);

        buttonConvert.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (rbRinggit.isChecked())
                {

                    ringgit_to_dollar();

                }

                if (rbDollar.isChecked())
                {

                    dollar_to_ringgit();

                }
            }
        });
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ringgit.setText("");
                ringgit.setText("");
            }
        });
    }

    private void ringgit_to_dollar()
    {
        checkRinggit = ringgit.getText().toString();
        if(checkRinggit.matches(""))
        {
            Toast.makeText(CurrencyConverter.this, "The fields are empty", Toast.LENGTH_SHORT).show();
        }
        else
        {
            try
            {
                result = Double.parseDouble(ringgit.getText().toString());
                result = result*0.248880;
                dollar.setText(String.format( "%.2f", result));

            } catch (NumberFormatException e)
            {
                Toast.makeText(CurrencyConverter.this, "Please enter number values", Toast.LENGTH_SHORT).show();
            }

        }
    }

    private void dollar_to_ringgit()
    {
        checkDollar = dollar.getText().toString();
        if(checkDollar.matches(""))
        {
            Toast.makeText(CurrencyConverter.this, "The fields are empty", Toast.LENGTH_SHORT).show();
        }
        else
        {
            try
            {
                result = Double.parseDouble(dollar.getText().toString());
                result = result*4.01808;
                ringgit.setText(String.format( "%.2f", result));

            } catch (NumberFormatException e)
            {
                Toast.makeText(CurrencyConverter.this, "Please enter number values", Toast.LENGTH_SHORT).show();
            }

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        String Name = "Cecilia Chan Wan Ting";
        String StudentId = "P18009703";
        String PersonalMessage = "The App is Created By Cecilia Chan!";
        Intent intent = new Intent();
        switch (item.getItemId())
        {

            case R.id.menu_about:
                ImageView image = new ImageView(this);
                image.setImageResource(R.drawable.profilepicture);
                AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                alertDialog.setTitle("About this App");
                alertDialog.setMessage(Name + "\n" + StudentId + "\n" + PersonalMessage + "\n"+"\n");
                alertDialog.setView(image);
                alertDialog.setButton("OK", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        //TODO auto-generated stub
                    }
                });
                alertDialog.show();
                return true;
            case R.id.calculator:
                intent.setClass(CurrencyConverter.this, MainActivity3.class);
                CurrencyConverter.this.startActivity(intent);
                return true;
            case R.id.menu_exit:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}