package com.example.user.profinal;


        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.widget.ImageView;
        import android.view.animation.AlphaAnimation;
        import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    ImageView calimg;
    AlphaAnimation animation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Set up fade in animation
        animation=new AlphaAnimation(0.0f,1.0f);
        animation.setDuration(2000);
        calimg=(ImageView) findViewById(R.id.imageView1);
        calimg.setAnimation(animation);

        //Thread to waste time while displaying splash screen
        Thread SplashThread=new Thread () {
            @Override
            public void run () {
                try {
                    synchronized (this) {
                        //Wait given period of time
                        wait (5000);
                    }
                } catch (InterruptedException ex) {

                }
                finish();

                //Run next activity
                Intent intent=new Intent ();
                intent.setClass(MainActivity.this,Welcome.class);
                MainActivity.this.startActivity(intent);

                //Terminate splash screen
                MainActivity.this.finish();
            }
        };
        SplashThread.start();


    }



}

