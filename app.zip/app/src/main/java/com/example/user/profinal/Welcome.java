package com.example.user.profinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;


public class Welcome extends AppCompatActivity{
    TextView calcu, currencyconvt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        calcu = (TextView) findViewById(R.id.calc);
        currencyconvt = (TextView) findViewById(R.id.currencyconv);

        calcu.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            startActivity(new Intent(Welcome.this, MainActivity2.class));
        }
        });

        currencyconvt.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Welcome.this, MainActivity3.class);
                startActivity(i);

            }
        });
    }
    }

